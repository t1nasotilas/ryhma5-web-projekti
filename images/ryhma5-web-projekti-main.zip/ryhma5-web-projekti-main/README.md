# ryhma5-web-projekti
#### Tommi Reunanen = t1nasotilas
#### Wilma Alaluusua = wilma-alaluusua
#### Vertti Winter = verttiwinter
#### Patrik Mikkonen = cryzmal
#### Santeri Korhonen = SanteriKorhonen
#### Viivi Dahlström = viividahlstrom
